/*
 * txtscreen.c
 */

#include "txtscreen.h"

int cur_L,cur_C;
static int scr_bgn_L,scr_bgn_C,scr_end_L,scr_end_C;
int scr_size_L,scr_size_C;
int cur_ATTR;
static char *vram=(char *)VRAM_BASE;
static char *vattr=(char *)(VRAM_BASE+0x1000);

void s_init(int L,int C){
	scr_size_L=L;scr_size_C=C;
	scr_bgn_L=0;scr_bgn_C=0;
	scr_end_L=L-1;scr_end_C=C-1;
	cur_ATTR=0x07;
	s_cls();
	s_cursoren(0);
}

char *s_getvaddr(int l,int c){
	return &vram[l*scr_size_C+c];
}

char *s_getvattr(int l,int c){
	return &vattr[l*scr_size_C+c];
}
void s_cls(void){
	int i;
	for(i=0;i<(scr_size_L*scr_size_C);i++){
		vram[i]=0x20;
		vattr[i]=0x07;
	}
	cur_L=0;
	cur_C=0;
}

int s_puts(char *str){
	int i,err;
	for(i=0;i<strlen(str);i++){
		if(str[i]=='\n'){
			s_newline();
		}else{
			if(err=s_putc(str[i]))return err;
		}

	}
	return 0;
}

int s_putc(char c){
	if(cur_C<0 || cur_C>(scr_size_C-1) || cur_L<0 || cur_L>(scr_size_L-1))return 1;
	if(c=='\n'){
		s_newline();
		return 0;
	}
	if(c=='\0')return 0;
	else{
		vram[cur_L*scr_size_C+cur_C]=c;
		vattr[cur_L*scr_size_C+cur_C]=cur_ATTR;

		if(cur_C>=scr_bgn_C && cur_C<=scr_end_C && cur_L>=scr_bgn_L && cur_L<=scr_end_L){	//in scroll area
			cur_C++;
			if(cur_C>scr_end_C)s_newline();
		}else{
			cur_C++;
		}
	}
	return 0;
}

void s_newline(void){
	int L,C;
	if(cur_L==scr_end_L){
		for(L=scr_bgn_L;L<scr_end_L;L++)for(C=scr_bgn_C;C<=scr_end_C;C++){
			vram[L*scr_size_C+C]=vram[(L+1)*scr_size_C+C];
			vattr[L*scr_size_C+C]=vattr[(L+1)*scr_size_C+C];
		}
		for(C=scr_bgn_C;C<=scr_end_C;C++){
			vram[L*scr_size_C+C]=0x20;
			vattr[L*scr_size_C+C]=0x07;
		}
	}else cur_L++;
	cur_C=scr_bgn_C;
}

void s_locate(int L,int C){
	if(L<0)L=cur_L;
	if(C<0)C=cur_C;
	cur_L=L;
	cur_C=C;
}

void s_setattr(int fgcolor,int bgcolor,int blink){
	int cur_fgcolor,cur_bgcolor,cur_blink;
	cur_fgcolor=(cur_ATTR & 0x07);
	cur_blink=(cur_ATTR & 0x80)>>3;
	cur_bgcolor=(cur_ATTR & 0x70)>>4;

	if(fgcolor<0)fgcolor=cur_fgcolor;
	if(bgcolor<0)bgcolor=cur_bgcolor;
	if(blink<0)blink=cur_blink;
	cur_ATTR=(bgcolor & 0x07);
	cur_ATTR<<=1;
	cur_ATTR|=(blink & 0x01);
	cur_ATTR<<=3;
	cur_ATTR|=(fgcolor & 0x07);
}

void s_setdattr(char attr){
	cur_ATTR=attr;
}

int s_setscroll(int bgn_L,int bgn_C,int end_L,int end_C){
	if(bgn_L<0)bgn_L=scr_bgn_L;
	if(bgn_C<0)bgn_C=scr_bgn_C;
	if(end_L<0)end_L=scr_end_L;
	if(end_C<0)end_C=scr_end_C;
	if(bgn_L<0 || bgn_L>=scr_size_L)return -1;
	if(bgn_C<0 || bgn_C>=scr_size_C)return -1;
	if(end_L<0 || end_L>=scr_size_L)return -1;
	if(end_C<0 || end_C>=scr_size_C)return -1;
	if(end_L<bgn_L)return -1;
	if(end_C<bgn_C)return -1;
	scr_bgn_L=bgn_L;
	scr_bgn_C=bgn_C;
	scr_end_L=end_L;
	scr_end_C=end_C;
	return 0;
}

int s_chgattr(int L,int C,int fgcolor,int bgcolor,int blink){
	int attr;
	if(L<0 || L>scr_size_L)return 1;
	if(C<0 || C>scr_size_C)return 1;
	attr=(bgcolor & 0x07);
	attr<<=1;
	attr|=(blink & 0x01);
	attr<<=3;
	attr|=(fgcolor&0x07);
	vattr[L*scr_size_C+C]=attr;
	return 0;
}

void s_chgdattr(int L,int C,char attr){
	vattr[L*scr_size_C+C]=attr;
}
void s_curup(void){
	if(cur_L>0)cur_L--;
}
void s_curdown(void){
	if(cur_L<scr_size_L-1)cur_L++;
}
void s_curleft(void){
	if(cur_C>0)cur_C--;
}
void s_curright(void){
	if(cur_C<scr_size_C-1)cur_C++;
}
void s_cursoren(int flag){
	IOWR_ALTERA_AVALON_PIO_DATA(TXT_CURSOREN_BASE,flag);
}
void s_setcursor(void){
	IOWR_ALTERA_AVALON_PIO_DATA(TXT_CURSORL_BASE,cur_L);
	IOWR_ALTERA_AVALON_PIO_DATA(TXT_CURSORC_BASE,cur_C);
}
void s_clrline(void){
	int i;
	cur_C=0;
	for(i=0;i<scr_size_C;i++){
		vram[cur_L*scr_size_C+i]=' ';
		vattr[cur_L*scr_size_C+i]=cur_ATTR;
	}
}
