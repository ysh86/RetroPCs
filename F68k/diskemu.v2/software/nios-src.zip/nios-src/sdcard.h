/*
 * sdcard.h
 */

#ifndef SDCARD_H_
#define SDCARD_H_

#include "diskio.h"
#include "spi.h"

DSTATUS SD_disk_status(void);
DSTATUS SD_disk_initialize(void);
DRESULT SD_disk_read(BYTE *buf,DWORD sector,UINT count);
DRESULT SD_disk_write(const BYTE *buf,DWORD sector,UINT count);
DRESULT SD_disk_ioctl(BYTE cmd,void *buf);
DWORD get_fattime (void);

#endif /* SDCARD_H_ */
