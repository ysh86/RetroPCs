/*
 * txtscreen.h
 */

#ifndef TXTSCREEN_H_
#define TXTSCREEN_H_

#include "system.h"
#include "altera_avalon_pio_regs.h"

void s_init(int L,int C);
void s_cls(void);
int s_puts(char *);
int s_putc(char );
void s_newline(void);
void s_locate(int,int);
void s_setattr(int,int,int);
int s_setscroll(int,int,int,int);
#endif /* TXTSCREEN_H_ */
