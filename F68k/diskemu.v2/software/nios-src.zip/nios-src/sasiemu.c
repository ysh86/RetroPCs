/*
 * sasiemu.c
 */

#include "sasiemu.h"

FATFS *Fat;
static int *diskflag;
static char **filename;
static int maxdisks;
static int errorcode;
static int erroraddr;
static int sectsize;
static char *vattr;
static int indoffset;
void ini_sasi(FATFS *fs,int num,int size,int *flag,char **name,char *addr,int locate){
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIOUT_BASE,0x00);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIBSY_BASE,0);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIREQ_BASE,0);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIIO_BASE,0);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASICD_BASE,0);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIMSG_BASE,0);
	IOWR_ALTERA_AVALON_PIO_IRQ_MASK(PIO_SASISEL_BASE,0x01);
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_SASISEL_BASE,0x00);
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_SASIRST_BASE,0x00);
	alt_irq_register(PIO_SASISEL_IRQ,0,intsasisel);
	diskflag=flag;
	filename=name;
	Fat=fs;
	sectsize=size;
	maxdisks=num;
	errorcode=0;
	erroraddr=0;
	vattr=addr;
	indoffset=locate;
}

void intsasisel(void){
	int i,din,sel,flag;
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_SASIRST_BASE,0x00);
	while(IORD_ALTERA_AVALON_PIO_DATA(PIO_SASISEL_BASE)){
		sel=1;
		din=IORD_ALTERA_AVALON_PIO_DATA(PIO_SASIIN_BASE);
		for(i=0;i<7;i++){
			if((sel & din)&&(diskflag[i*2]!=HD_NONE || diskflag[i*2+1]!=HD_NONE)){
				flag=sasi_proc(i);
				if(flag){
					IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_SASIRST_BASE,0x00);
					IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIOUT_BASE,0x00);
					IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIREQ_BASE,0);
					IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIIO_BASE,0);
					IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASICD_BASE,0);
					IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIMSG_BASE,0);
					IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIBSY_BASE,0);
				}
				break;
			}
			sel<<=1;
		}
	}
}

int senddata(int data){
	int flag;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIOUT_BASE,data);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIREQ_BASE,1);
	do{
		if(IORD_ALTERA_AVALON_PIO_EDGE_CAP(PIO_SASIRST_BASE))return -1;
	}while(!IORD_ALTERA_AVALON_PIO_DATA(PIO_SASIACK_BASE));
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIREQ_BASE,0);
	do{
		if(IORD_ALTERA_AVALON_PIO_EDGE_CAP(PIO_SASIRST_BASE))return -1;
	}while(IORD_ALTERA_AVALON_PIO_DATA(PIO_SASIACK_BASE));
	return 0;
}

char recvdata(int *flag){
	char data;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIREQ_BASE,1);
	do{
		if(IORD_ALTERA_AVALON_PIO_EDGE_CAP(PIO_SASIRST_BASE)){
			*flag=-1;
			return 0;
		}
	}while(!IORD_ALTERA_AVALON_PIO_DATA(PIO_SASIACK_BASE));
	data=IORD_ALTERA_AVALON_PIO_DATA(PIO_SASIIN_BASE);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIREQ_BASE,0);
	do{
		if(IORD_ALTERA_AVALON_PIO_EDGE_CAP(PIO_SASIRST_BASE)){
			*flag=-1;
			return 0;
		}
	}while(IORD_ALTERA_AVALON_PIO_DATA(PIO_SASIACK_BASE));
	*flag=0;
	return data;
}

int sasi_proc(int ID){
	int cmdnum,opcode,unit,addr,num,cont,din,status;
	extern int scr_size_C;
	int flag;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIBSY_BASE, 1);
	do{
		if(IORD_ALTERA_AVALON_PIO_EDGE_CAP(PIO_SASIRST_BASE))return -1;
	}while(IORD_ALTERA_AVALON_PIO_DATA(PIO_SASISEL_BASE));
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASICD_BASE,1);
	for(cmdnum=0;cmdnum<6;cmdnum++){
		din=recvdata(&flag);
		if(flag)return -1;
		switch(cmdnum){
		case 0:
			opcode=din & 0xff;
			break;
		case 1:
			unit=(din & 0xe0)>>5;
			addr=din & 0x1f;
			break;
		case 2:
		case 3:
			addr<<=8;
			addr|=(din & 0xff);
			break;
		case 4:
			num=din & 0xff;
			break;
		case 5:
			cont=din & 0xff;
			break;
		default:
			break;
		}
	}
//	printf("ID %X,UNIT %d :opcode %02X,addr=%06X,num=%d,cont=%02x\n",ID,unit,opcode,addr,num,cont);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASICD_BASE,0);
	if(diskflag[ID*2+unit]!=HD_NONE){
		vattr[scr_size_C*(ID*2+unit+indoffset)]=0x40;
		switch(opcode){
		case 0x00:
			status=sasi_chkready(ID*2+unit,&flag);
			break;
		case 0x01:
			status=sasi_recaribrate(ID*2+unit,&flag);
			break;
		case 0x03:
			status=sasi_sensestatus(ID*2+unit,&flag);
			break;
		case 0x04:
			status=sasi_format(ID*2+unit,&flag);
			break;
		case 0x08:
			status=sasi_read(ID*2+unit,addr,num,&flag);
			break;
		case 0x0a:
			status=sasi_write(ID*2+unit,addr,num,&flag);
			break;
		case 0xc2:
			status=sasi_readconf(ID*2+unit,&flag);
			break;
		default:
			flag=0;
			status=0x00;
			break;
		}
		if(flag)return -1;
	}
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIIO_BASE,1);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASICD_BASE,1);
	if(senddata(status))return -1;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIMSG_BASE,1);
	if(senddata(0x00))return -1;;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIIO_BASE,0);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIMSG_BASE,0);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASICD_BASE,0);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIBSY_BASE, 0);
	vattr[scr_size_C*(ID*2+unit+indoffset)]=0x07;
}

int sasi_chkready(int unit,int *flag){
	int status;
	FIL file;
	status=f_open(&file,filename[unit],FA_READ | FA_OPEN_ALWAYS);
	*flag=0;
	if(status==FR_OK){
		f_close(&file);
		return 0;
	}else return status;
}

int sasi_recaribrate(int unit,int *flag){
	*flag=0;
	return 0;
}

int sasi_sensestatus(int unit,int *flag){
	int i;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIIO_BASE,1);
	for(i=0;i<4;i++){
		switch(i){
		case 0:
			*flag=senddata(errorcode);
			break;
		case 1:
			*flag=senddata((erroraddr>>16)&0xff);
			break;
		case 2:
			*flag=senddata((erroraddr>>8)&0xff);
			break;
		case 3:
			*flag=senddata(erroraddr&0xff);
			break;
		default:
			break;
		}
		if(*flag){
			return -1;
		}
	}
	errorcode=0;
	erroraddr=0;
	return 0;
}

int sasi_format(int unit,int *flag){
	int status;
	FIL file;
	*flag=0;
	if((status=f_open(&file,filename[unit],FA_WRITE | FA_CREATE_ALWAYS))==FR_OK){
		f_close(&file);
		return 0;
	}else return status;
}

int sasi_read(int unit,int addr,int num,int *flag){
	int status,i,j,len;
	char buf[sectsize+1];
	FIL file;
	if((status=f_open(&file,filename[unit],FA_READ | FA_WRITE | FA_OPEN_ALWAYS))!=FR_OK)return status;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SASIIO_BASE,1);
	for(i=0;i<num;i++){
		if((status=f_lseek(&file,sectsize*addr))!=FR_OK)return status;
		if((status=f_read(&file,buf,sectsize,&len))!=FR_OK)return status;
		for(j=0;j<sectsize;j++){
			*flag=senddata(buf[j]);
			if(*flag){
				f_close(&file);
				return -1;
			}
		}
		addr++;
	}
	f_close(&file);
	return 0;
}

int sasi_write(int unit,int addr,int num,int *flag){
	int status,i,j,len;
	char buf[sectsize+1];
	FIL file;
	if((status=f_open(&file,filename[unit],FA_WRITE | FA_OPEN_ALWAYS))!=FR_OK)return status;
	for(i=0;i<num;i++){
		if((status=f_lseek(&file,sectsize*addr))!=FR_OK)return status;
		for(j=0;j<sectsize;j++){
			buf[j]=recvdata(&flag);
			if(flag){
				f_close(&file);
				return FR_DENIED;
			}
		}
		if((status=f_write(&file,buf,sectsize,&len))!=FR_OK)return status;
		if(len!=sectsize)return FR_DENIED;
		addr++;
	}
	f_close(&file);
	return 0;
}

int sasi_readconf(int unit,int *flag){
	int i;
	for(i=0;i<10;i++){
		recvdata(flag);
		if(*flag)return -1;
	}
	return 0;
}
