/*
 * crccalc.c
 */

static int crcbuf;
static int crcpoly;
static int crclen;
static int mask;
static int crctable[256];

void crcclr(int x){
	crcbuf=x;
}

void crcinit(int len,int clrdat,int poly){
	int i,j,a,msb;
	crcbuf=clrdat;
	mask=1<<len;
	mask--;
	msb=1<<(len-1);
	for(i=0;i<256;i++){
		int a=i<<8;
		for(j=0;j<8;j++)a=(a&msb)?poly^(a<<1):a<<1;
		a&=mask;
		crctable[i]=a;
	}
	crclen=len;
}

/* int crccalc(int dat){
	int i;
	for(i=0;i<crclen;i++){
		crcbuf<<=1;
		if(mask & crcbuf)crcbuf^=crcpoly;
	}
	return crcbuf;
} */

int crccalc(char dat){
	crcbuf=crctable[((crcbuf>>8)^dat)&0x0ff]^(crcbuf<<8);
	crcbuf&=mask;
	return crcbuf;
}
int crcget(void){
	return crcbuf;
}
